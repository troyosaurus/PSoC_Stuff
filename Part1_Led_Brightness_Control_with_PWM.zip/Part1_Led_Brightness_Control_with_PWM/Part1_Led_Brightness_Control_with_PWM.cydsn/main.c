/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <device.h>

void main()
{
 uint32 output;

    /* Start the components */
    Clock_1_Start();
    LCD_Char_Start();
    ADC_DelSig_1_Start();
    PWM_1_Start();

    /* Start the ADC conversion */
    ADC_DelSig_1_StartConvert();

    /* Display the value of ADC output on LCD */
    LCD_Char_Position(0, 0);
    LCD_Char_PrintString("POT");
    LCD_Char_Position(1, 0);
    LCD_Char_PrintString("ADC_DEC");

    for(;;)
    {
        //if(ADC_DelSig_1_IsEndConversion(ADC_DelSig_1_WAIT_FOR_RESULT))
        output = ADC_DelSig_1_GetResult32()/(65.6016016016);
        PWM_1_WriteCompare(999-(output));
        LCD_Char_Position(0, 9);
        LCD_Char_PrintNumber(ADC_DelSig_1_GetResult16());
        LCD_Char_Position(1, 9);
        LCD_Char_PrintNumber(output);
    }
}

/* [] END OF FILE */

/* Place your initialization/startup code here (e.g. MyInst_Start()) */

    /* CyGlobalIntEnable; */ /* Uncomment this line to enable global interrupts. */
//    for(;;)
//    {
        /* Place your application code here. */
//    }