/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/*******
***********************************
* Place your includes, defines and code
here
******************************************/

#include <device.h>
#include <stdio.h>

uint16 timer_freq;
//uint32 ADC_value;

/*This is what the ISR does every 2ms */
CY_ISR(SUB_ROUTINE)
{
uint32 PWM;
PWM = Counter_ReadCounter();    //Read the counter value
//PWM = PWM*1000;
timer_freq = PWM/0.002;        //.002 is the period of the timer (2ms)
Timer_STATUS;
Counter_WriteCounter(0);        //Clear the counter value
}

void main()
{
CyGlobalIntEnable; // Enable global interrupts

/*Interrupt Initializations*/
isr_1_StartEx(SUB_ROUTINE);

/* Place your initialization/startup code here (e.g. MyInst_Start()) */
ADC_Start();
PWM_Start();
Counter_Start();
LCD_Start();
Timer_Start();

/* Start the ADC conversion of your analog values */
ADC_StartConvert();

/* After the initializations, the code enters an infinite "for" loop. When the interrupt occurs, *
* the program remembers where it left off in the code, performs the application programming interface 
*routines and calculations in the subroutine. After finishing the subroutine, 
* the program goes back to where the main() code left off. */

for(;;)
{
    //int number = 0;
    if(ADC_IsEndConversion(ADC_WAIT_FOR_RESULT)) {
        uint32 ADC_value = ADC_GetResult32();

        /*LCD_Position(0,6);
        //LCD_PrintNumber(ADC_GetResult32());
        
        //int pot = (ADC_value/65535);
        //int pot = (ADC_value * 24000)/65535;
        //PWM_WriteCompare(65535-(pot));
        
        //   if(pot <= 0)                //Lower and upper bound conditions of the ADC value with 1 as the minimum and
        //        pot = 1;                //24000 as the maximum.
        //   if(pot >= 24000)
        //        pot = 24000;

        //int period = (24000/pot)*65535; */
       
        LCD_Position(1,0);
        LCD_PrintString("ADC:");

        PWM_WritePeriod(ADC_value);
        PWM_WriteCompare(ADC_value/2);
        LCD_Position(1,6);
        LCD_PrintNumber(ADC_value);
        }
        LCD_Position(0,0);
        LCD_PrintString("Freq:");
        LCD_Position(0,6);
        LCD_PrintNumber(timer_freq);
        
    }
}
